# Project: https://snv-project-movies.ru/
# PullRequest: https://github.com/NikitaSavchuk97/movies-explorer-frontend/pull/2
# Homepage: https://NikitaSavchuk97.github.io/movies-explorer-frontend
# Layout: https://disk.yandex.ru/d/a5cYtkQ_jHTDtA